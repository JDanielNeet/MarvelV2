

import Foundation
import CoreData

@objc(FavCharacter)
public class FavCharacter: NSManagedObject {

}


