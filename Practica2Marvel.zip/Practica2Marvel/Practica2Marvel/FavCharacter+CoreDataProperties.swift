

import Foundation
import CoreData


extension FavCharacter {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<FavCharacter> {
        return NSFetchRequest<FavCharacter>(entityName: "FavCharacter")
    }

    @NSManaged public var name: String?
    @NSManaged public var thumbnail: String?
    @NSManaged public var descr: String?
    @NSManaged public var url: String?

}

extension FavCharacter : Identifiable {

}
