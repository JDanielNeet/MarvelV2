

import UIKit

class DetailViewController: UIViewController {

    var datosCharacter : Character!
    var datosFavChar: FavCharacter!
    var favoritos : FavManager!
    var favoriteFlag = false
    
    @IBOutlet weak var thumbnail: UIImageView!
    
    @IBOutlet weak var Descr: UILabel!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var urlLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if(favoriteFlag){
            let url = URL(string: (datosFavChar.thumbnail!))
            thumbnail.sd_setImage(with: url)
            name.text = datosFavChar.name
            Descr.text = datosFavChar.descr
            urlLabel.text = datosFavChar.url
        }// Do any additional setup after loading the view.        }
        else{
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            favoritos = FavManager(context: context)
            let url = URL(string: (datosCharacter.thumbnail.url))
            thumbnail.sd_setImage(with: url)
            name.text = datosCharacter.name
            Descr.text = datosCharacter.description
            urlLabel.text = datosCharacter.resourceURI       // Do any additional setup after loading the view.
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
    @IBAction func `return`(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    
    @IBAction func favorite(_ sender: Any) {
        if(favoriteFlag){
            print("Ya es favorito")
        }
        else{
        favoritos.createFav(name: datosCharacter.name,
                            thumbnail: datosCharacter.thumbnail.url,
                            descr: datosCharacter.description,
                            url: datosCharacter.resourceURI)
        }
    }
    
    
}
