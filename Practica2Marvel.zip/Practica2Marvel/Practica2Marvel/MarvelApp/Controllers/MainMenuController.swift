
import UIKit

class MainMenuController: UIViewController {

    
    @IBOutlet weak var attributionText: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateTextView()

        // Do any additional setup after loading the view.
    }
    

    func updateTextView(){
        let path = "https://marvel.com"
        let text = attributionText.text ?? ""
        let attributedString = NSAttributedString.makeHyperlink(for: path, in: text, as: "Data provided by Marvel. © 2024 MARVEL")
        attributionText.attributedText = attributedString
    }
    
    // MARK: - Navigation

     //In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         //Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "favChar"{
            let destination = segue.destination as! ViewController
            destination.favoriteFlag = true
        }
        
        if segue.identifier == "listChar"{
            let destination = segue.destination as! ViewController
            destination.favoriteFlag = false
        }
    }
    

}
