//
//  DoubleExtesion.swift
//  MarvelApp
//
//  Created by Rafael González on 30/04/24.
//

import Foundation

extension Double {
    var asString : String{
        String(self)
    }
    
}

